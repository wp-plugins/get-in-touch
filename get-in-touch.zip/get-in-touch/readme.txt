=== GET IN TOUCH ===
Contributors: Think201, Vivek Pandey
Donate link: http://example.com/
Tags: get in touch, wordpress plugin, contact form, map, enquiry form, google map integration
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Get In Touch allows you to create contact forms, save contact form requests, generate custom google maps, keep track of mails, sorting of requests.

== Description ==

Get In Touch plug-in allows you to generate form by adding input controls to it dynamically.This plug-in allows you to integrate map along with your form and have a track of mails received.


== Salient Features == 

- Add any number of input controls to your form.
- Include maps with your form.
- Colour Customization of map used.
- Track mails received through your form.


== Plugin Support ==

If you have a question or problem with the GET IN TOUCH plugin, post it on the support forum and we will help you.


== Installation == 

To begin with:
1.Upload the get-in-touch.zip' file from the Plugins->Add New page in the WordPress administration panel.
2.Activate the plugin through the 'Plugins' menu in WordPress 
3.Go to Settings menu under 'WP Security' and start activating the security features of the plugin.

== Usage ==

Go to the Get In Touch menu after you activate the plugin and follow the instructions.


== Screenshots ==

Check the following page for screenshots:
http://developer.think201.com/plugins/get-in-touch-wordpress-contact-form-plugin


== Frequently Asked Questions ==

Check the following page for F.A.Q (see the faq section):
http://developer.think201.com/plugins/get-in-touch-wordpress-contact-form-plugin


== Upgrade Notice ==

None

== Changelog ==

= 1.0 =
- First commit to the WP repository.



